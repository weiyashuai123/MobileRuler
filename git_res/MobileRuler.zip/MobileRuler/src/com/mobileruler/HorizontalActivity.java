package com.mobileruler;

import android.os.Bundle;

public class HorizontalActivity extends BaseActivity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_straightedge);
		StraightedgeView ruler = (StraightedgeView) findViewById(R.id.ruler);
		ruler.setTextSize(12)
			.setLineLength(10)
			.build();
	}

}
